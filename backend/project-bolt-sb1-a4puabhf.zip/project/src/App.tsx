import React from 'react';
import { Activity, Brain, Calendar, FileText, Heart, Shield, Stethoscope, Upload, Users, ClipboardList, MessageSquare, BarChart, ArrowRight } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-white to-blue-50">
      {/* Hero Section */}
      <header className="bg-white/80 backdrop-blur-sm sticky top-0 z-50 shadow-sm">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-blue-600 animate-pulse" />
              <span className="text-xl font-bold gradient-text">DDMS</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#features" className="text-gray-600 hover:text-blue-600 transition-colors">Features</a>
              <a href="#patients" className="text-gray-600 hover:text-blue-600 transition-colors">For Patients</a>
              <a href="#doctors" className="text-gray-600 hover:text-blue-600 transition-colors">For Doctors</a>
              <a href="#contact" className="text-gray-600 hover:text-blue-600 transition-colors">Contact</a>
            </div>
            <div className="flex space-x-4">
              <button className="button-secondary">Login</button>
              <button className="button-primary">Sign Up</button>
            </div>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-6 py-24">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="gradient-text">Disease Detection</span>
              <br />Management System
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Your Health, Our Priority. Advanced AI-powered platform for early disease detection and management.
            </p>
            <div className="flex space-x-4">
              <button className="button-primary flex items-center space-x-2">
                <span>Get Started</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button className="button-secondary">Learn More</button>
            </div>
          </div>
          <div className="md:w-1/2 mt-12 md:mt-0">
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg opacity-30 blur-lg"></div>
              <img 
                src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=800"
                alt="Medical Technology"
                className="relative rounded-lg shadow-2xl animate-float"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Diseases Section */}
      <section className="bg-white/50 backdrop-blur-sm py-24">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-4">
            <span className="gradient-text">Comprehensive</span> Disease Detection
          </h2>
          <p className="text-xl text-gray-600 text-center mb-16 max-w-2xl mx-auto">
            Our AI-powered system specializes in detecting various diseases with high accuracy and reliability.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { name: 'Tuberculosis', icon: <Activity className="h-8 w-8" />, description: 'Early detection through X-ray analysis' },
              { name: 'Malaria', icon: <Brain className="h-8 w-8" />, description: 'Rapid diagnosis from blood samples' },
              { name: 'Skin Cancer', icon: <FileText className="h-8 w-8" />, description: 'AI-powered lesion detection' },
              { name: 'Breast Cancer', icon: <Shield className="h-8 w-8" />, description: 'Early-stage detection via imaging' },
              { name: 'Pneumonia', icon: <Stethoscope className="h-8 w-8" />, description: 'X-ray based diagnosis' },
              { name: 'COVID-19', icon: <Users className="h-8 w-8" />, description: 'Quick symptom analysis' },
            ].map((disease, index) => (
              <div key={index} className="bg-white/80 backdrop-blur-sm p-8 rounded-xl hover-card">
                <div className="text-blue-600 mb-4 bg-blue-50 w-16 h-16 rounded-lg flex items-center justify-center">
                  {disease.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{disease.name}</h3>
                <p className="text-gray-600">{disease.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section - For Patients */}
      <section id="patients" className="py-24">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-1/2 mb-12 md:mb-0">
              <h2 className="text-4xl font-bold mb-6">
                For <span className="gradient-text">Patients</span>
              </h2>
              <div className="space-y-6">
                <div className="flex items-center space-x-4 p-4 bg-white/80 backdrop-blur-sm rounded-lg hover-card">
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <Upload className="h-6 w-6 text-blue-600" />
                  </div>
                  <p className="text-gray-600">Upload medical reports for AI analysis</p>
                </div>
                <div className="flex items-center space-x-4 p-4 bg-white/80 backdrop-blur-sm rounded-lg hover-card">
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <Activity className="h-6 w-6 text-blue-600" />
                  </div>
                  <p className="text-gray-600">Receive instant preliminary results</p>
                </div>
                <div className="flex items-center space-x-4 p-4 bg-white/80 backdrop-blur-sm rounded-lg hover-card">
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <Calendar className="h-6 w-6 text-blue-600" />
                  </div>
                  <p className="text-gray-600">Schedule doctor consultations</p>
                </div>
              </div>
              <button className="mt-8 button-primary">Get Started Now</button>
            </div>
            <div className="md:w-1/2 md:pl-12">
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg opacity-30 blur-lg"></div>
                <img 
                  src="https://images.unsplash.com/photo-1584982751601-97dcc096659c?auto=format&fit=crop&w=800"
                  alt="Patient Care"
                  className="relative rounded-lg shadow-xl animate-float"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section - For Doctors */}
      <section id="doctors" className="bg-white/50 backdrop-blur-sm py-24">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-1/2">
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg opacity-30 blur-lg"></div>
                <img 
                  src="https://images.unsplash.com/photo-1551190822-a9333d879b1f?auto=format&fit=crop&w=800"
                  alt="Doctor Dashboard"
                  className="relative rounded-lg shadow-xl animate-float"
                />
              </div>
            </div>
            <div className="md:w-1/2 mt-12 md:mt-0 md:pl-12">
              <h2 className="text-4xl font-bold mb-6">
                For <span className="gradient-text">Doctors</span>
              </h2>
              <div className="space-y-6">
                <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl hover-card">
                  <div className="flex items-start space-x-4">
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <ClipboardList className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Smart Patient Management</h3>
                      <p className="text-gray-600">Access comprehensive patient histories and AI-assisted diagnoses in one place.</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl hover-card">
                  <div className="flex items-start space-x-4">
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <MessageSquare className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Seamless Communication</h3>
                      <p className="text-gray-600">Connect with patients through secure messaging and virtual consultations.</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl hover-card">
                  <div className="flex items-start space-x-4">
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <BarChart className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Advanced Analytics</h3>
                      <p className="text-gray-600">Track patient progress and treatment outcomes with detailed analytics.</p>
                    </div>
                  </div>
                </div>
              </div>
              <button className="mt-8 button-primary">Join as a Doctor</button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <Heart className="h-8 w-8 text-blue-400" />
                <span className="text-xl font-bold">DDMS</span>
              </div>
              <p className="text-gray-400">Your trusted partner in health management and disease detection.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-blue-400 transition-colors">Home</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Services</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-blue-400 transition-colors">Disease Detection</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Patient Portal</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">Doctor Dashboard</a></li>
                <li><a href="#" className="hover:text-blue-400 transition-colors">AI Analysis</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
              <ul className="space-y-2 text-gray-400">
                <li>support@yourwebsite.com</li>
                <li>1-800-HEALTH</li>
                <li>123 Medical Center Drive</li>
                <li>Healthcare City, HC 12345</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2025 Disease Detection Management System. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;